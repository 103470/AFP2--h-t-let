<?php
    session_start();

    $con = mysqli_connect('localhost','root','','afp2') or die("Hiba történt");

    $errors = array();

?>