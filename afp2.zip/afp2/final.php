<html>
<head>
	<title>Kérdőív</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
	<nav>
       <div class="container">

       <div class="menu">
			<a href=""></a>
			<a href=""></a>
        </div>

       </div>
    </nav>
	

	<main>
			<div class="final">
				<h2>Köszönjük, hogy időt szántál a kérdőív kitöltésésre.</h2>
				<h2>Válaszod sokat jelent nekünk!</h2>
				<br><br>
				<a class="start" href="main.php">Vissza a  főoldalra</a>
				
				
			</div>

			
			

	</main>
</body>
</html>